-- Mengatur mode SQL dan zona waktu
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- --------------------------------------------------------
-- Database: `tokoku`
-- --------------------------------------------------------

-- --------------------------------------------------------
-- Tabel `keranjang`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `keranjang`;
CREATE TABLE `keranjang` (
  `id_product` varchar(5) NOT NULL,
  `product_name` varchar(120) NOT NULL,
  `jumlah` int(10) NOT NULL,
  `price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------
-- Tabel `products`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id_product` varchar(5) NOT NULL,
  `product_name` varchar(120) NOT NULL,
  `stock` int(10) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `products` (`id_product`, `product_name`, `stock`, `price`) VALUES
('A0001', 'Mechanical Keyboard', 25, 1500000),
('A0002', 'Gaming Mouse', 30, 700000),
('A0003', 'Monitor 24 Inch', 12, 2000000),
('A0004', 'Gaming Headset', 18, 900000),
('A0005', 'Mouse Pad', 40, 50000),
('A0006', 'External Hard Drive 1TB', 15, 1200000),
('A0007', 'USB Hub', 50, 100000),
('A0008', 'Webcam', 22, 600000),
('A0009', 'Laptop Stand', 35, 300000),
('A0010', 'Cooling Pad', 27, 250000),
('A0011', 'Portable SSD 500GB', 10, 1400000),
('A0012', 'Wireless Router', 14, 800000),
('A0013', 'HDMI Cable', 50, 150000),
('A0014', 'Bluetooth Adapter', 33, 75000),
('A0015', 'Surge Protector', 20, 200000);

-- --------------------------------------------------------
-- Tabel `receipt`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `receipt`;
CREATE TABLE `receipt` (
  `id_receipt` int(11) NOT NULL AUTO_INCREMENT,
  `id_product` varchar(5) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`id_receipt`),
  FOREIGN KEY (`id_product`) REFERENCES `products`(`id_product`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `receipt` (`id_receipt`, `id_product`, `quantity`) VALUES
(1, 'A0001', 5),
(2, 'A0002', 10),
(3, 'A0003', 7),
(4, 'A0004', 12),
(5, 'A0005', 3),
(6, 'A0006', 8),
(7, 'A0007', 15),
(8, 'A0008', 6),
(9, 'A0009', 9),
(10, 'A0010', 4),
(11, 'A0011', 2),
(12, 'A0012', 7),
(13, 'A0013', 5),
(14, 'A0014', 8),
(15, 'A0015', 3);

-- --------------------------------------------------------
-- Tabel `user`
-- --------------------------------------------------------

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(20) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id`, `username`, `password`, `status`) VALUES
('1', 'admin', 'pass123', 'admin'),
('2', 'user1', 'pass123', 'pembeli'),
('3', 'user2', 'pass123', 'pembeli'),
('4', 'user3', 'pass123', 'pembeli'),
('5', 'user4', 'pass123', 'pembeli');

-- --------------------------------------------------------

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

COMMIT;